import { useState } from "react";
import Sidebar from "./Sidebar";
import TopHeader from "./TopHeader";

type AppShellProps = {
  children: React.ReactNode;
  header?: React.ReactNode;
};

export default function AppShell({ children, header }: AppShellProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#eff5ff_0%,#edf4ff_100%)] p-3 md:p-4">
      <div className="mx-auto flex max-w-[1500px] gap-4">
        <Sidebar mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} />

        <main className="min-w-0 flex-1">
          <div className="space-y-4">
            {header ?? <TopHeader />}
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}