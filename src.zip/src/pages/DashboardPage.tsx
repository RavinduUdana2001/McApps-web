import AppShell from "../components/layout/AppShell";
import QuickAccessGrid from "../components/dashboard/QuickAccessGrid";
import AlertsSection from "../components/dashboard/AlertsSection";
import NewsSection from "../components/dashboard/NewsSection";
import RightColumn from "../components/dashboard/RightColumn";

export default function DashboardPage() {
  return (
    <AppShell>
      <div className="space-y-6">
        <section className="grid grid-cols-1 items-start gap-6 xl:grid-cols-[minmax(0,1fr)_280px]">
          <QuickAccessGrid mode="dashboard" />
          <RightColumn />
        </section>

        <AlertsSection />
        <NewsSection />
      </div>
    </AppShell>
  );
}